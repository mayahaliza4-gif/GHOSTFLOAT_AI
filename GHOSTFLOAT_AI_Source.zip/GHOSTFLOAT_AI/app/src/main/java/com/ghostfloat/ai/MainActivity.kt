package com.ghostfloat.ai

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions

private val Bg = Color(0xFF080B10)
private val Panel = Color(0xFF151B24)
private val Neon = Color(0xFF55F2A5)
private val Purple = Color(0xFF9B7CFF)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(
                colorScheme = darkColorScheme(
                    background = Bg, surface = Panel, primary = Neon,
                    secondary = Purple, onBackground = Color.White, onSurface = Color.White
                )
            ) {
                GhostFloatScreen(
                    onStartBubble = { startBubble() },
                    onScan = { uri, done -> recognizeText(uri, done) }
                )
            }
        }
    }

    private fun startBubble() {
        if (!Settings.canDrawOverlays(this)) {
            val intent = Intent(
                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:$packageName")
            )
            startActivity(intent)
            return
        }
        ContextCompat.startForegroundService(
            this, Intent(this, FloatingBubbleService::class.java)
        )
    }

    private fun recognizeText(uri: Uri, done: (String) -> Unit) {
        try {
            val image = InputImage.fromFilePath(this, uri)
            val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
            recognizer.process(image)
                .addOnSuccessListener { result ->
                    done(result.text.ifBlank { "Tidak ada teks yang terbaca. Coba gambar lebih jelas." })
                    recognizer.close()
                }
                .addOnFailureListener { error ->
                    done("OCR gagal: ${error.localizedMessage ?: "kesalahan tidak diketahui"}")
                    recognizer.close()
                }
        } catch (e: Exception) {
            done("Tidak dapat membuka file: ${e.localizedMessage}")
        }
    }
}

@Composable
private fun GhostFloatScreen(
    onStartBubble: () -> Unit,
    onScan: (Uri, (String) -> Unit) -> Unit
) {
    var recognized by remember { mutableStateOf("Hasil OCR akan muncul di sini.") }
    var scanStatus by remember { mutableStateOf("") }
    var question by remember { mutableStateOf("") }
    var apiKey by remember { mutableStateOf("") }
    var aiResult by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }

    val picker = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            scanStatus = "Membaca dokumen..."
            onScan(uri) {
                recognized = it
                scanStatus = "Pemindaian selesai."
            }
        }
    }

    Column(
        Modifier.fillMaxSize().background(Bg).verticalScroll(rememberScrollState()).padding(18.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Text("GHOSTFLOAT", color = Neon, fontSize = 27.sp)
        Text("AI STUDY ASSISTANT  •  CYBERPUNK EDITION", color = Purple, fontSize = 11.sp)
        Text(
            "Asisten belajar untuk materi dan latihan. Floating bubble mengikuti izin Android dan tidak digunakan untuk menyembunyikan aktivitas saat ujian.",
            color = Color.LightGray, fontSize = 12.sp
        )

        Card(colors = CardDefaults.cardColors(containerColor = Panel)) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("FLOATING ASSISTANT", color = Neon)
                Text("Bubble kecil dapat dipindahkan di layar saat overlay diizinkan.")
                Button(onClick = onStartBubble, modifier = Modifier.fillMaxWidth()) {
                    Text("Aktifkan Floating Bubble")
                }
            }
        }

        Card(colors = CardDefaults.cardColors(containerColor = Panel)) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("ONE-TAP SMART SCAN", color = Neon)
                Text("Pilih gambar atau PDF materi/latihan untuk membaca teks dengan OCR.")
                Button(
                    onClick = { picker.launch(arrayOf("image/*", "application/pdf")) },
                    modifier = Modifier.fillMaxWidth()
                ) { Text("Pilih Gambar / PDF") }
                Text(scanStatus, color = Purple)
                OutlinedTextField(
                    value = recognized,
                    onValueChange = { recognized = it },
                    label = { Text("Teks yang terdeteksi") },
                    modifier = Modifier.fillMaxWidth(),
                    minLines = 4
                )
            }
        }

        Card(colors = CardDefaults.cardColors(containerColor = Panel)) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("AI STUDY EXPLANATION", color = Neon)
                OutlinedTextField(
                    value = apiKey, onValueChange = { apiKey = it },
                    label = { Text("OpenAI API key (jangan dibagikan)") },
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = question, onValueChange = { question = it },
                    label = { Text("Pertanyaan atau instruksi belajar") },
                    modifier = Modifier.fillMaxWidth(), minLines = 2
                )
                Button(
                    enabled = !busy && apiKey.isNotBlank() && (question.isNotBlank() || recognized.isNotBlank()),
                    onClick = {
                        busy = true
                        aiResult = "Memproses..."
                        val prompt = """
                            Bantu saya memahami materi/latihan berikut. Jelaskan langkah demi langkah,
                            tunjukkan konsep yang digunakan, dan nyatakan jika informasi tidak cukup.
                            Gunakan Bahasa Indonesia.
                            Teks hasil OCR: $recognized
                            Pertanyaan tambahan: $question
                        """.trimIndent()
                        Thread {
                            val response = OpenAiClient.ask(apiKey.trim(), prompt)
                            (android.os.Looper.getMainLooper()).let { looper ->
                                android.os.Handler(looper).post {
                                    aiResult = response
                                    busy = false
                                }
                            }
                        }.start()
                    },
                    modifier = Modifier.fillMaxWidth()
                ) { Text(if (busy) "Memproses..." else "Jelaskan dengan AI") }
                if (aiResult.isNotBlank()) Text(aiResult, color = Color.White)
            }
        }
        Text("GHOSTFLOAT AI • Versi starter 1.0", color = Color.Gray, fontSize = 11.sp)
    }
}
