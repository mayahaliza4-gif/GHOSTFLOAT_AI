GHOSTFLOAT AI - Starter Project
================================

Persyaratan:
- Android Studio / Gradle build environment, atau GitHub Actions.
- JDK 17.
- Android SDK Platform 35.
- Perangkat Android 8.0 (API 26) atau lebih baru untuk menjalankan aplikasi.

Build lewat GitHub dari HP:
1. Buat repository baru di https://github.com/new.
2. Upload semua isi folder project ini ke repository.
3. Pastikan file .github/workflows/android.yml ikut terunggah.
4. Buka tab Actions di repository.
5. Jalankan workflow "Build GHOSTFLOAT AI APK" atau tunggu build otomatis.
6. Setelah selesai, buka hasil workflow dan unduh artifact GHOSTFLOAT_AI-debug-apk.
7. Ekstrak ZIP artifact, lalu pasang app-debug.apk di HP.

Catatan:
- Ini starter project, bukan APK yang sudah dibuild atau diuji pada perangkat nyata.
- APK dari workflow ini adalah debug APK, bukan release APK bertanda tangan untuk distribusi.
- Floating overlay membutuhkan izin "Display over other apps".
- Android/OEM dapat membatasi foreground service dan overlay.
- Smart Scan memilih file secara eksplisit dari galeri/dokumen. Tidak ada perekaman layar diam-diam.
- Gunakan untuk belajar dan latihan yang diizinkan, bukan untuk menghindari aturan ujian.
- API key dimasukkan saat runtime; jangan commit API key ke GitHub.
- Untuk aplikasi produksi, pindahkan panggilan AI ke backend milik sendiri agar API key tidak tertanam/terekspos di APK.
